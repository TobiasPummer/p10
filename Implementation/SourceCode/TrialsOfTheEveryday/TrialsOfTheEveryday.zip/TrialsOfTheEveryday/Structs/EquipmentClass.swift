//
//  EquipmentClass.swift
//  TrialsOfTheEveryday
//
//  Created by Sebastian Maier on 22.09.24.
//

import Foundation

struct EquipmentClass {
    var ID: Int
    var BenefittingStat: String
}
