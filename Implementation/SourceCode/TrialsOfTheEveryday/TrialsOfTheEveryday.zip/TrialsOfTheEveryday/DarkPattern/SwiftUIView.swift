//
//  SwiftUIView.swift
//  TrialsOfTheEveryday
//
//  Created by Tobias Pummer on 09.06.25.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
