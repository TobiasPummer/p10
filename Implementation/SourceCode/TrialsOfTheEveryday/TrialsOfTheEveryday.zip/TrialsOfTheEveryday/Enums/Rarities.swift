//
//  Rarities.swift
//  TrialsOfTheEveryday
//
//  Created by Tobias Pummer on 03.06.25.
//

import Foundation

enum Rarities: String, Hashable {
    case common
    case rare
    case epic
    case legendary
}

